package com.in28minutes.rest.webservices.restfulwebservices.helloworld;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloworldController {

	@GetMapping(path = "/hello-world")
	public String helloWorld() {
		return "Hello World Rest-web-services";

	}

	@GetMapping(path = "/hello-world-bean/")
	public HelloworldBean helloWorldBean() {
		return new HelloworldBean("Hello World Rest-web-services...");

	}

	@GetMapping(path = "/hello-world/path-variable/{name}")
	public HelloworldBean helloWorldPathVariable(@PathVariable String name) {
		return new HelloworldBean("Hello World : " + name);

	}

}
