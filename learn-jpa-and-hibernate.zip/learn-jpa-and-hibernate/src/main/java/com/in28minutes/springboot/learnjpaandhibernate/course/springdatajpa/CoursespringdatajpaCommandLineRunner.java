package com.in28minutes.springboot.learnjpaandhibernate.course.springdatajpa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.in28minutes.springboot.learnjpaandhibernate.course.Course;

@Component
public class CoursespringdatajpaCommandLineRunner implements CommandLineRunner {

	@Autowired
	private CourseSpringDataJpaRepository jpa_repository;

	@Override
	public void run(String... args) throws Exception {
		jpa_repository.save(new Course(1, "Learn AWS Spring_DataJPA", "in28Minutes"));
		jpa_repository.save(new Course(2, "Learn Azure Spring_DataJPA", "Avinash"));
		jpa_repository.save(new Course(3, "Learn GC Spring_DataJPA", "in28Minutes"));
		jpa_repository.save(new Course(4, "Learn Azure Spring_DataJPA", "Rathod"));
		jpa_repository.deleteById(2l);

		System.out.println("_______SpringDataJPA__________");

		System.out.println(jpa_repository.findById(1l));
		System.out.println(jpa_repository.findById(4l));
		System.out.println(jpa_repository.findById(4l));

		System.out.println(jpa_repository.findAll());
		System.out.println(jpa_repository.count());
		System.out.println("______findByAuthor______");
		System.out.println(jpa_repository.findByAuthor("in28Minutes"));
		
		System.out.println("______findByName______");
		System.out.println(jpa_repository.findByName("Learn Azure Spring_DataJPA"));

	}

}
